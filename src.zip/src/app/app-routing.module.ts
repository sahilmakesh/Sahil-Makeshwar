import { NgModule } from '@angular/core';
import { RouterLinkActive, RouterModule, Routes } from '@angular/router';
import { PaymentmethodsComponent } from './paymentmethods/paymentmethods.component';
import { ProductsComponent } from './products/products.component';
import { RegisterComponent } from './register/register.component';


const routes: Routes = [
{
  path:"products" ,component:ProductsComponent 
},
{
  path:"register" , component:RegisterComponent
},
{
  path:"paymentmethods",component:PaymentmethodsComponent
}




];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
