import { Component, OnInit } from '@angular/core';
import { bank_pay_list } from './paymethodlist';

@Component({
  selector: 'app-paymentmethods',
  templateUrl: './paymentmethods.component.html',
  styleUrls: ['./paymentmethods.component.css']
})
export class PaymentmethodsComponent implements OnInit {
  paymentlist= bank_pay_list
  
  gofor:string=""
  name:string=""
   service_selected=''
  constructor() { }

  ngOnInit(): void {
  }

  onSelect(value:string){
    this.gofor=value
  }

}