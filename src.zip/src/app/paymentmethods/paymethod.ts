export interface paymethod{
    name:string
}