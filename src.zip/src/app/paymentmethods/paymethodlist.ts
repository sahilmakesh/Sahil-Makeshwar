import { paymethod } from  "./paymethod"
export const bank_pay_list:paymethod[]=[
   
    {
        name:'SBI credit card'
    },
    {
       name:'RBL Debit Card'
    },
    {
        name:'HDFC credit card'
    },
    {
        name:'ICICI emi card'
    },
   
]