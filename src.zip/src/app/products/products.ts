export interface prods{
    name:string
}