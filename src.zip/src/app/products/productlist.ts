import { prods } from  "./products"
export const prod_list:prods[]=[
   
    {
        name:'Redmi Phone'
    },
    {
       name:'Oneplus Phone'
    },
    {
        name:'Semsung Phone'
    },
    {
        name:'Car animated'
    }
    
]