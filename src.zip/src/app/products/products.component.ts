import { Component, Input, OnInit, Output } from '@angular/core';

import { prod_list } from './productlist';
import { prods } from './products';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  prodlist= prod_list
 
  gofor:string=""
  name:string=""
   service_selected=''
  myimage1:string="assets/images/image1.PNG";
  myimage2:string="assets/images/image2.PNG";
  myimage3:string="assets/images/image3.PNG";
  myimage4:string="assets/images/car.PNG";

  product={}
  productlist=[
    {
        prodname:"Redmi Phone",
        id:1
    },
    {
        prodname:"OnePlus Phone",
        id:2
    },
    {
        prodname:"Semsung Phone",
        id:3
    }]
  isunchanged=true;
  class= "special"
  cartlist:any=[];
  addprodtocart (product:any){
    this.cartlist.push(product)
    return;
  }
 
 @Input() prod:prods[]=prod_list;

 

  constructor() { }

  ngOnInit(): void {
  }

  onSelect(value:string){
    this.gofor=value
  }
 

}

  
